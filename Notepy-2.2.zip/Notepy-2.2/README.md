# Notepy
simpliest notepad you can ever find

`// RedibleSky   - helper / uploader`

`// user0-07161  - improving Notepy a LOT`

`// voxjgithub   - making Russian option for Notepy`

`// orca-pet3910 -  owner`

i love notepy cuz it can run in winRE

also, don't tell about bugs for linux only, notepy is not meant to be run on it anyway
