# Important note

The TK-Inter theme is from [this project](https://github.com/rdbende/Azure-ttk-theme/tree/v2.1.0), big thanks to the developer of it
